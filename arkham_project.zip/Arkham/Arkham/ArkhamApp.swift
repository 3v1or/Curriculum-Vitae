import SwiftUI
import AVFoundation
import SystemConfiguration
import Combine
import Foundation
import Speech

// MARK: - 1. CONFIGURACIÓN VISUAL NERV (COLORES OFICIALES)
extension Color {
    static let evaPurple = Color(red: 0.15, green: 0.0, blue: 0.25)
    static let evaGreen = Color(red: 0.2, green: 1.0, blue: 0.0)
    static let evaOrange = Color(red: 1.0, green: 0.6, blue: 0.0)
    static let evaBlack = Color(red: 0.03, green: 0.03, blue: 0.05)
}

// MARK: - 2. MODELOS DE DATOS
struct ChatMessage: Identifiable {
    let id = UUID()
    let text: String
    let isUser: Bool
}

// MARK: - 3. MOTORES DE VOZ Y ESCUCHA (ARKHAM SYSTEMS)
class ArkhamVoice: ObservableObject {
    private let synthesizer = AVSpeechSynthesizer()
    func speak(_ text: String) {
        let utterance = AVSpeechUtterance(string: text)
        utterance.voice = AVSpeechSynthesisVoice(language: "es-MX")
        utterance.rate = 0.48
        utterance.pitchMultiplier = 0.65
        synthesizer.speak(utterance)
    }
    func stop() { synthesizer.stopSpeaking(at: .immediate) }
}

class ArkhamListener: ObservableObject {
    @Published var transcript: String = ""
    @Published var isRecording: Bool = false
    private var audioEngine = AVAudioEngine()
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?
    private let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "es-MX"))
    
    func requestPermissions() { SFSpeechRecognizer.requestAuthorization { _ in } }
    
    func startRecording() {
        transcript = ""
        let node = audioEngine.inputNode
        request = SFSpeechAudioBufferRecognitionRequest()
        guard let request = request else { return }
        request.shouldReportPartialResults = true
        task = recognizer?.recognitionTask(with: request) { result, _ in
            if let result = result { DispatchQueue.main.async { self.transcript = result.bestTranscription.formattedString } }
        }
        let format = node.outputFormat(forBus: 0)
        node.installTap(onBus: 0, bufferSize: 1024, format: format) { b, _ in self.request?.append(b) }
        try? audioEngine.start()
        isRecording = true
    }
    
    func stopRecording() {
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        request?.endAudio()
        isRecording = false
    }
}

// MARK: - 4. CEREBRO MAGI (VIEWMODEL)
import Foundation
import Combine

// MARK: - CEREBRO MAGI (VIEWMODEL)
class ArkhamViewModel: ObservableObject {
    @Published var chatHistory: [ChatMessage] = []
    @Published var isProcessing: Bool = false
    @Published var modoRedActivado: Bool = false
    private let voice = ArkhamVoice()
    
    // --- 1. CONFIGURACIÓN DE RED ---
    // Consigue tu llave gratis en serper.dev para que MAGI pueda usar Google
    private let searchAPIKey = "37512320a1e25f869c324f5c4c328722543eed9c"

    func deliverResponse(_ text: String, speak: Bool = true) {
        DispatchQueue.main.async {
            self.chatHistory.append(ChatMessage(text: text, isUser: false))
            if speak { self.voice.speak(text) }
        }
    }
    
    func stopMagiSpeech() { voice.stop() }

    func processCommand(prompt: String) {
        guard !prompt.isEmpty else { return }
        voice.stop()
        self.chatHistory.append(ChatMessage(text: prompt, isUser: true))
        let cmd = prompt.lowercased()
        
        // --- 2. COMANDOS TÁCTICOS LOCALES ---
        if cmd.contains("hardware") { deliverResponse(getSystemInfo()); return }
        if cmd.contains("escanear") || cmd.contains("red") {
            deliverResponse("Sincronizando red local...")
            scanLocalPorts()
            return
        }
        if cmd.contains("auditoria") || cmd.contains("auditoría") {
            deliverResponse("Iniciando auditoría de conexiones...")
            runQuickAudit()
            return
        }

        // --- 3. PROCESAMIENTO DE IA ---
        self.isProcessing = true
        if modoRedActivado {
            // Si el switch está en ON, primero va a Google y luego a Ollama
            buscarEnInternet(query: prompt)
        } else {
            // Si está en OFF, solo usa el cerebro local de Ollama
            askOllama(prompt: prompt, contextExtra: "")
        }
    }

    // --- 4. FUNCIÓN DE BÚSQUEDA REAL (EL ENLACE SATELITAL) ---
    private func buscarEnInternet(query: String) {
        guard let url = URL(string: "https://google.serper.dev/search") else { return }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue(searchAPIKey, forHTTPHeaderField: "X-API-KEY")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String: Any] = ["q": query, "gl": "mx", "hl": "es"]
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)

        URLSession.shared.dataTask(with: request) { data, _, error in
            if let data = data,
               let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let organic = json["organic"] as? [[String: Any]] {
                
                // Tomamos los fragmentos de los primeros 3 resultados de Google
                let snippets = organic.prefix(3).compactMap { $0["snippet"] as? String }.joined(separator: " ")
                
                DispatchQueue.main.async {
                    // Le pasamos esos datos a la IA para que redacte la respuesta
                    self.askOllama(prompt: query, contextExtra: snippets)
                }
            } else {
                DispatchQueue.main.async {
                    self.isProcessing = false
                    self.deliverResponse("ERROR: Enlace satelital fallido. Revisa tu API Key de Serper.")
                }
            }
        }.resume()
    }

    // --- 5. CONEXIÓN CON OLLAMA ---
    func askOllama(prompt: String, contextExtra: String) {
        guard let url = URL(string: "http://127.0.0.1:11434/api/generate") else { return }
        
        var systemMsg = "Eres MAGI, IA táctica de NERV. Tono analítico y militar. "
        if !contextExtra.isEmpty {
            systemMsg += "DATOS RECUPERADOS DE LA RED: \(contextExtra). Usa esta información para responder al Piloto. "
        }
        
        // Historial para que no pierda el hilo
        systemMsg += "\nHistorial reciente:\n"
        for m in chatHistory.suffix(4) {
            systemMsg += "\(m.isUser ? "Piloto" : "MAGI"): \(m.text)\n"
        }
        systemMsg += "Piloto: \(prompt)\nMAGI:"

        let body: [String: Any] = ["model": "llama3.2:3b", "prompt": systemMsg, "stream": false]
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try? JSONSerialization.data(withJSONObject: body)

        URLSession.shared.dataTask(with: req) { d, _, _ in
            DispatchQueue.main.async {
                self.isProcessing = false
                if let d = d, let j = try? JSONSerialization.jsonObject(with: d) as? [String: Any], let res = j["response"] as? String {
                    self.deliverResponse(res)
                }
            }
        }.resume()
    }

    // --- 6. HERRAMIENTAS DE DIAGNÓSTICO ---
    private func getSystemInfo() -> String {
        let p = ProcessInfo.processInfo
        return "[DIAGNÓSTICO MAGI]\nOS: \(p.operatingSystemVersionString)\nRAM: \(p.physicalMemory / 1024 / 1024 / 1024) GB\nESTADO: NOMINAL."
    }

    private func scanLocalPorts() {
        self.deliverResponse("REPORTE: Puerto 11434 (Ollama) detectado como ACTIVO.")
    }

    private func runQuickAudit() {
        DispatchQueue.global(qos: .userInitiated).async {
            let task = Process(); task.executableURL = URL(fileURLWithPath: "/usr/sbin/netstat"); task.arguments = ["-an"]
            let pipe = Pipe(); task.standardOutput = pipe
            try? task.run(); task.waitUntilExit()
            let lines = String(data: pipe.fileHandleForReading.readDataToEndOfFile(), encoding: .utf8)?.components(separatedBy: .newlines).count ?? 0
            self.deliverResponse("AUDITORÍA: Análisis de \(lines) conexiones completado.")
        }
    }
}

// MARK: - 5. INTERFAZ DE USUARIO (RESTAURACIÓN ESTÉTICA)
struct RootView: View {
    @State private var log = false
    var body: some View {
        Group {
            if log { NERVDashboardView() }
            else { NERVAccessView(isLoggedIn: $log) }
        }.frame(minWidth: 950, minHeight: 650).preferredColorScheme(.dark)
    }
}

struct NERVAccessView: View {
    @Binding var isLoggedIn: Bool
    @State private var pin = ""
    var body: some View {
        VStack(spacing: 30) {
            VStack {
                Image(systemName: "triangle.fill").foregroundColor(.evaOrange).font(.system(size: 40))
                Text("NERV").font(.system(size: 60, weight: .black, design: .monospaced))
            }.foregroundColor(.white)
            SecureField("CÓDIGO MAGI", text: $pin).textFieldStyle(.plain).multilineTextAlignment(.center).font(.system(size: 24, design: .monospaced)).padding().frame(width: 300).background(Color.evaPurple.opacity(0.4)).border(Color.evaGreen, width: 2).onSubmit { if pin.count >= 3 { isLoggedIn = true } }
            Button("SINCRONIZAR") { if pin.count >= 3 { isLoggedIn = true } }.buttonStyle(.plain).padding().background(Color.evaGreen).foregroundColor(.black).font(.system(.body, design: .monospaced, weight: .bold))
        }.frame(maxWidth: .infinity, maxHeight: .infinity).background(Color.evaBlack)
    }
}

struct NERVDashboardView: View {
    @StateObject private var viewModel = ArkhamViewModel()
    var body: some View {
        NavigationSplitView {
            VStack(alignment: .leading, spacing: 0) {
                HStack {
                    Text("CONTROL TÁCTICO").font(.system(.caption, design: .monospaced, weight: .bold))
                    Spacer(); Text("MAGI-1").font(.system(size: 8, design: .monospaced))
                }.padding(8).background(Color.evaOrange).foregroundColor(.black)
                
                HStack {
                    Image(systemName: viewModel.modoRedActivado ? "globe" : "lock.shield")
                    Text(viewModel.modoRedActivado ? "RED: ONLINE" : "RED: OFFLINE").font(.system(size: 10, design: .monospaced))
                    Spacer(); Toggle("", isOn: $viewModel.modoRedActivado).labelsHidden().toggleStyle(SwitchToggleStyle(tint: .evaOrange))
                }.padding(10).background(Color.evaBlack.opacity(0.5))
                
                List {
                    Section(header: Text("MÓDULOS TÁCTICOS").foregroundColor(.evaOrange)) {
                        Button(action: { viewModel.processCommand(prompt: "hardware") }) { Label("Estado del EVA-01", systemImage: "cpu") }
                        Button(action: { viewModel.processCommand(prompt: "escanear") }) { Label("Sincronización Red", systemImage: "network") }
                        Button(action: { viewModel.processCommand(prompt: "auditoria") }) { Label("Auditoría MAGI", systemImage: "checkmark.shield") }
                    }.foregroundColor(.evaGreen).font(.system(.body, design: .monospaced))
                }
                .scrollContentBackground(.hidden).background(Color.evaPurple.opacity(0.2))
                Text("SINCRONIZACIÓN: 41.3%").font(.system(size: 9, design: .monospaced)).padding(8).frame(maxWidth: .infinity).border(Color.evaGreen, width: 1).foregroundColor(.evaGreen)
            }.navigationSplitViewColumnWidth(min: 260, ideal: 260)
        } detail: { NERVTerminalView(viewModel: viewModel) }
    }
}

struct NERVTerminalView: View {
    @ObservedObject var viewModel: ArkhamViewModel
    @StateObject private var listener = ArkhamListener()
    @State private var inputPrompt = ""

    var body: some View {
        VStack(spacing: 0) {
            // Header con ABORT
            HStack {
                Text("MAGI SYSTEM INTERFACE - 'ARKHAM' PROTOCOL").font(.system(.headline, design: .monospaced, weight: .bold))
                Spacer()
                Button(action: { viewModel.stopMagiSpeech() }) {
                    HStack { Image(systemName: "speaker.slash.fill"); Text("ABORT") }
                        .font(.system(size: 10, weight: .bold, design: .monospaced))
                        .padding(6).background(Color.red).foregroundColor(.white)
                }.buttonStyle(PlainButtonStyle())
            }.padding(10).background(Color.evaGreen).foregroundColor(.black)

            // CHAT TÁCTICO CON BORDES
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 20) {
                        ForEach(viewModel.chatHistory) { m in
                            HStack {
                                if m.isUser { Spacer() }
                                VStack(alignment: m.isUser ? .trailing : .leading, spacing: 4) {
                                    Text(m.isUser ? "PILOTO >" : "MAGI >").font(.system(size: 9, design: .monospaced)).foregroundColor(m.isUser ? .white : .evaGreen)
                                    Text(m.text)
                                        .padding(12)
                                        .background(m.isUser ? Color.evaPurple.opacity(0.6) : Color.evaBlack)
                                        .border(m.isUser ? Color.white.opacity(0.6) : Color.evaGreen, width: 1)
                                        .foregroundColor(m.isUser ? .white : .evaGreen)
                                        .font(.system(.body, design: .monospaced))
                                }
                                if !m.isUser { Spacer() }
                            }.id(m.id)
                        }
                    }.padding()
                }.onChange(of: viewModel.chatHistory.count) { _ in proxy.scrollTo(viewModel.chatHistory.last?.id) }
            }.background(Color.evaBlack)

            // Barra de entrada
            HStack {
                Text(">").foregroundColor(.evaOrange).bold()
                TextField("INGRESAR COMANDO...", text: $inputPrompt)
                    .textFieldStyle(PlainTextFieldStyle()).foregroundColor(.evaGreen).font(.system(.body, design: .monospaced))
                    .onSubmit { if !inputPrompt.isEmpty { viewModel.processCommand(prompt: inputPrompt); inputPrompt = "" } }
                
                Button(action: {
                    if listener.isRecording {
                        listener.stopRecording()
                        if !listener.transcript.isEmpty { viewModel.processCommand(prompt: listener.transcript); inputPrompt = "" }
                    } else { listener.startRecording() }
                }) {
                    Image(systemName: listener.isRecording ? "mic.fill" : "mic").foregroundColor(listener.isRecording ? .red : .evaGreen).font(.title2)
                }.buttonStyle(PlainButtonStyle())
            }.padding().background(Color.evaBlack).border(Color.evaOrange, width: 1)
            .onChange(of: listener.transcript) { new in if listener.isRecording { inputPrompt = new } }
        }.onAppear { listener.requestPermissions() }
    }
}

@main struct NERVArkhamApp: App {
    var body: some Scene { WindowGroup { RootView() } }
}
